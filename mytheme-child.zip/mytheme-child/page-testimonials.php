<?php
/* Template Name: Testimonials Page */
get_header(); ?>

<section class="testimonial-section">
    <h2>TESTIMONIALS</h2>
    <div class="testimonial-slider">
        
        <div class="testimonial-item">
            <h3>Lorem ipsum dolor sit amet, consectetur adipisicing elit</h3>
            <p class="testimonial-text">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
            </p>
            <div class="testimonial-author">
                <img src="<?php echo get_stylesheet_directory_uri(); ?>/media/user1.jpg" alt="User">
                <span>by Lorem Ipsum</span>
            </div>
        </div>

        <!-- You can duplicate above .testimonial-item for more testimonials -->

        <button class="testimonial-prev">←</button>
        <button class="testimonial-next">→</button>
    </div>
</section>

<?php get_footer(); ?>
