<?php
function transport_theme_setup() {
    // Enable menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'transport-theme')
    ));
}
add_action('after_setup_theme', 'transport_theme_setup');

function transport_theme_scripts() {
    // Google Fonts
    wp_enqueue_style('raleway-font', 'https://fonts.googleapis.com/css2?family=Raleway:wght@400;700&display=swap');

    // Bootstrap CSS
    wp_enqueue_style('bootstrap-css', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css');

    // Theme CSS
    wp_enqueue_style('theme-style', get_stylesheet_uri());

    // Bootstrap JS
    wp_enqueue_script('bootstrap-js', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js', array('jquery'), null, true);
}
add_action('wp_enqueue_scripts', 'transport_theme_scripts');
