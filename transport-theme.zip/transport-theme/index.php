<style>
    body {
  font-family: 'Raleway', sans-serif;
  
}

h1{
  font-size: 38px !important;
  font-weight: 700;
  color:#fff !important;

}

.hero {
  background: url('http://localhost/wordpress/wp-content/uploads/2025/08/banner1.jpg') no-repeat center center/cover;
  height: 80vh;
  display: flex;
  align-items: center;
  text-align: center;
}

.about, .testimonials {
  background-color: #00305b;
  color: #fff;
}
p{
    color:#fff;
    font-size:16px;
}

.about-section {
  background-color: #00305b;
  color: #ffffff;
  font-family: 'Raleway', sans-serif;
}

.about-section h2 {
  font-size: 38px;
}

.about-section p {
  font-size: 16px;
  line-height: 1.6;
}
.border-start-custom {
  border-left: 1px solid rgba(255, 255, 255, 0.3); /* thin white line */
}
.@media (max-width: 991px) {
  .border-start-custom {
    border-left: none;
    border-top: 1px solid rgba(255, 255, 255, 0.3); /* horizontal line */
    margin-top: 20px;
    padding-top: 20px;
  }
}
 </style>   
<?php
get_header(); ?>

<div class=" text-center">
   <section class="hero">
  <div class="container">
    <h1><b>Lorem</b> Ipsum Dolor</h1>
    <p>Lorem ipsum dolor sit amet lorem ipsum dolor sit amet</p>
    <a href="#contact" class="btn mt-3 p-2 px-5" style="background-color: #ffffff;color: #00305b;border-radius:20px;"><b>CONTACT US</b></a>
  </div>
</section>
</div>

<section class="about-section py-5">
  <div class="container">
    <div class="row align-items-center">
      
      
      <div class="col-lg-8 mb-4 mb-lg-0 text-white">
        <h2><b>LOREM</b> IPSUM DOLOR SIT AMET</span></h2>
        <p>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
          Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure 
          dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
        </p>
        <p>
          Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam. 
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
        </p>
      </div>

      
      <div class="col-lg-4 text-center text-white   pt-4 pt-lg-0">
        <div class="row">
          <div class="col-6 mb-4 border-start-custom pt-4 pt-lg-0">
            <img src="http://localhost/wordpress/wp-content/uploads/2025/08/team1.png" alt="Team" class="img-fluid mb-2" style="width:60px;">
            <p class="mb-0">MEET OUR TEAM</p>
          </div>
          <div class="col-6 mb-4  border-start-custom pt-4 pt-lg-0">
            <img src="http://localhost/wordpress/wp-content/uploads/2025/08/building.png" alt="Projects" class="img-fluid mb-2" style="width:60px;">
            <p class="mb-0">SEE OUR PROJECTS</p>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>
<?php
    
    $testimonial_page = get_page_by_path('testimonial-2'); // slug of my your page
    if ($testimonial_page) {
        $testimonial_content = apply_filters('the_content', $testimonial_page->post_content);
        echo '<section class="testimonials-section">';
        echo $testimonial_content;
        echo '</section>';
    }
?>

<?php get_footer(); ?>
