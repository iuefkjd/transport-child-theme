
<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
 footer {
  background: #0a3566;
  color: #fff;
  padding: 50px 20px 20px;
   font-family: 'Raleway', sans-serif;
}
.footer-container {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 40px;
  max-width: 1200px;
  margin: auto;
}
.footer-box h3 {
  margin-bottom: 15px;
  font-size: 16px;
  text-transform: uppercase;
}
.footer-box p {
  font-size: 14px;
  line-height: 1.6;
}
.footer-links {
  list-style: none;
  padding: 0;
  margin: 0 0 15px;
}
.footer-links li {
  display: inline-block;
  margin-right: 15px;
}
.footer-links li a {
  color: #fff;
  text-decoration: none;
  font-size: 14px;
}
.footer-links li a:hover {
  text-decoration: underline;
}

/* Social Icons */
.footer-socials a {
  display: inline-block;
  margin-right: 10px;
  color: #fff;
  font-size: 18px;
  transition: 0.3s;
}
.footer-socials a:hover {
  color: #1f80c1;
}


.footer-box p i {
  margin-right: 8px;
  color: #1f80c1;
}

/* Bottom Line */
.footer-bottom {
  text-align: center;
  margin-top: 30px;
  font-size: 14px;
  border-top: 1px solid rgba(255,255,255,0.2);
  padding-top: 10px;
}
p{
    font-size:16px;
}

</style>
</head>
<footer>
  <div class="footer-container">
    <!-- About -->
    <div class="footer-box">
      <h3>ABOUT</h3>
      <p style="  font-size:16px;">
        Libero consectetur fames montes habitasse lorem hendrerit dictumst sit blandit. 
        Commodo justo, blandit lobortis. Libero consectetur fames montes.
      </p>
    </div>

    
    <div class="footer-box">
      <h3>LINKS</h3>
      <ul class="footer-links" style="  font-size:16px;">
        <li><a href="#">Sitemap</a></li>
        <li><a href="#">Privacy Statement</a></li>
        <li><a href="#">Contact</a></li>
      </ul>
      <div class="footer-socials">
        <a href="#"><i class="fab fa-facebook"></i></a>
        <a href="#"><i class="fab fa-twitter"></i></a>
        <a href="#"><i class="fab fa-instagram"></i></a>
        <a href="#"><i class="fab fa-linkedin"></i></a>
      </div>
    </div>

    
    <div class="footer-box">
      <h3>CONTACT US</h3>
      <p style="  font-size:16px;"><i class="fa fa-map-marker"></i> 4019 Lorem Ipsum, Dolor sit amet, Lorem<br> Lorem p2k-2D5</p>
      <p style="  font-size:16px;"><i class="fa fa-phone"></i> +123 456 7890 / 91</p>
      <p style="  font-size:16px;"><i class="fa fa-envelope"></i> info@example.com</p>
    </div>
  </div>

  <div class="footer-bottom" style="  font-size:16px;">
    © 2021 Lorem ipsum.
  </div>
</footer>


<?php wp_footer(); ?>
</body>
</html>
