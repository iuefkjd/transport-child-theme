<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Header Example</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
     <style>
    body {
      font-family: 'Raleway', sans-serif;
    }
    .navbar {
      background-color: #00305b;
    }
    .navbar-nav .nav-link {
      color: #ffffff !important;
      font-size: 16px;
      margin-right: 20px;
    }
    .navbar-brand {
      color: #ffffff !important;
      font-weight: 700;
    }
    .contact-btn {
      background: #ffffff;
      color: #00305b;
      border-radius: 25px;
      padding: 8px 20px;
      font-weight: 600;
    }
    .contact-btn i {
      margin-right: 5px;
    }
  </style>
</head>
<body>
   <nav class="navbar navbar-expand-lg py-4">
  <div class="container">
    <!-- Logo -->
    <img src="http://localhost/wordpress/wp-content/uploads/2025/08/logo.png" style="width:250px;"/>
    <!-- Mobile Toggle -->
    <button class="navbar-toggler text-white" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>

    <!-- Menu -->
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="#">About</a></li>
        <li class="nav-item"><a class="nav-link" href="#">Projects</a></li>
        <li class="nav-item"><a class="nav-link" href="#">Lorem</a></li>
        <li class="nav-item"><a class="nav-link" href="#">Ipsum</a></li>
        <li class="nav-item"><a class="nav-link" href="#">Lorem Ipsum</a></li>
        <li class="nav-item"><a class="nav-link" href="#">Contact</a></li>
      </ul>

      <!-- Contact Button -->
      <a href="tel:123456789" class="btn contact-btn ms-lg-3">
        <i class="bi bi-telephone"></i> 123 456 789
      </a>
    </div>
  </div>
</nav>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>